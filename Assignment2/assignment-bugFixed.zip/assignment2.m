% The Script
imA = readImage('sign.tif');
imB = readImage('stripes.tif');
mapIntoImage(imA,imB);